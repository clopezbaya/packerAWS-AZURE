const http = require("http");

const server = http.createServer((req, res) => {
  console.log("respuesta del servidor...");
  res.end("Christian Lopez Baya");
});

const puerto = 3000;

server.listen(puerto, () => {
  console.log("Escuchando...");
});